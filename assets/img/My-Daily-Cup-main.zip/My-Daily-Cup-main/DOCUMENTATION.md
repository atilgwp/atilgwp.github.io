# API Resources
Links or code bits to help us along our journey.

   * https://developers.google.com/identity/sign-in/web/sign-in
   * https://github.com/GoogleChromeLabs/google-sign-in
   
